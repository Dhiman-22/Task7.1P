import React from 'react'
import { useNavigate } from 'react-router-dom'

export const LandingPage = () => {
    const navigate = useNavigate();
    const handleClick=()=>{
        navigate("/Login")
    }

    const handleReg = ()=>{
        navigate("/signup")
    }
  return (
    <div>
        <h1>Welcome to landing page of the website to proceed further do login/register on the website</h1>
        <button onClick={handleClick}>Login</button>
        <button onClick={handleReg}>Register</button>
    </div>
  )
}
