import { useContext, useState } from "react"
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContextProvider";

const Login=()=>{
    const{isAuth,login,logout,setToken,token}=useContext(AuthContext)
    const [email,setEmail]=useState("")
    const [pass,setPass]=useState("")
    
    const navigate = useNavigate();
    const handleSubmit=()=>{
        const payload={
            email:email,
            pass:pass
        }
        // connecting FE with BE
        fetch("http://localhost:4500/users/login",{
            method: "POST",
            headers:{
                "Content-type":"application/json"
            },
            body: JSON.stringify(payload)
        }).then(res=>res.json())
        .then(res=>{
            console.log(res)
            alert(res.msg)     
             
            setToken(res.token) 
            
        })
        .catch(err=>console.log(err))
    }

    if(token){
        login();
        navigate("/home")
    }

    const handleClick=()=>{
        navigate("/signup")
    }
    return (
        <>
        <h1>Login Page</h1>
        <div>
            Email: <input type="text" placeholder="Enter email" value={email} onChange={(e)=>setEmail(e.target.value)}/>
            Password: <input type="password" placeholder="Enter Password" value={pass} onChange={(e)=>setPass(e.target.value)}/>
            <p>If you are visiting first time on the website or not registered on the website than do registration first: <button onClick={handleClick}>Register</button></p>
            <button onClick={handleSubmit}>Submit</button>
        </div>
        </>
    )
}

export {Login} 