


import React, { useContext } from 'react'
import { NavLink,Link } from 'react-router-dom'
import { AuthContext } from '../context/AuthContextProvider'
 


export const Navbar = () => {
    const {isAuth}=useContext(AuthContext)
const links = [
    {path:"/",title:"DEV@Deakin"},   
    {path:"/home",title:"Home Page"},
    {path:"/notes",title:"Notes Page"},
    {path:"/login",title:"Login Page"},
    {path:"/signup",title:"Register Page"},
    {path:"/logout",title:isAuth?"LogOut":null}
]
  return (
    <div style={{display:"flex",alignment:"center",justifyContent:"space-around",padding:"10px",background:"pink"}}> 
        {links.map((link)=>{
   return <Link style={{textDecoration:"none"}} key={link.path} to={link.path}>{link.title}</Link>
        })}
    </div>
  )
}
